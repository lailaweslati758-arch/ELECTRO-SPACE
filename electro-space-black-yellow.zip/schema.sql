-- ELECTRO SPACE : à exécuter dans Supabase > SQL Editor
-- ÉTAPE 1 : remplacez l'e-mail ci-dessous par VOTRE e-mail (ce compte deviendra administrateur)
create table public.admin_emails(email text primary key);
alter table public.admin_emails enable row level security;
insert into public.admin_emails values ('VOTRE_EMAIL@exemple.com');
-- ÉTAPE 2 : copiez TOUT ce fichier dans Supabase > SQL Editor puis cliquez sur Run

create table public.profiles(id uuid primary key references auth.users on delete cascade, email text, full_name text, phone text,
  role text not null default 'customer' check (role in ('customer','admin')), created_at timestamptz default now());
create table public.categories(id uuid primary key default gen_random_uuid(), name text unique not null, slug text unique not null);
create table public.products(id uuid primary key default gen_random_uuid(), category_id uuid references public.categories on delete set null,
  name text not null, description text, price numeric(10,3) not null check (price>=0), sale_price numeric(10,3) check (sale_price>=0),
  stock int not null default 0 check (stock>=0), image_url text, is_featured boolean default false, created_at timestamptz default now());
-- Variantes : chaque produit peut avoir plusieurs couleurs / types, chacun avec ses propres images et son stock
create table public.product_variants(id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products on delete cascade,
  color text, type text, price numeric(10,3) check (price>=0), stock int not null default 0 check (stock>=0),
  images text[] not null default '{}', created_at timestamptz default now());
create table public.orders(id uuid primary key default gen_random_uuid(), user_id uuid references public.profiles on delete set null,
  status text not null default 'en_attente' check (status in ('en_attente','confirmee','expediee','livree','annulee')),
  total numeric(10,3) not null default 0, customer_name text, phone text, address text, created_at timestamptz default now());
create table public.order_items(id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders on delete cascade,
  product_id uuid references public.products on delete set null, variant_id uuid references public.product_variants on delete set null,
  product_name text not null, variant_label text, unit_price numeric(10,3) not null, quantity int not null check (quantity>0));
create table public.cart_items(id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles on delete cascade,
  product_id uuid not null references public.products on delete cascade, variant_id uuid references public.product_variants on delete cascade,
  quantity int not null check (quantity>0), created_at timestamptz default now());
create unique index cart_unique on public.cart_items(user_id,product_id,coalesce(variant_id,'00000000-0000-0000-0000-000000000000'::uuid));

create table public.reviews(id uuid primary key default gen_random_uuid(), product_id uuid not null references public.products on delete cascade,
  user_id uuid not null references public.profiles on delete cascade, author_name text, rating int not null check (rating between 1 and 5),
  comment text, created_at timestamptz default now(), unique(product_id,user_id));

create function public.is_admin() returns boolean language sql security definer stable set search_path=public as
$$ select exists(select 1 from profiles where id=auth.uid() and role='admin') $$;
create function public.my_role() returns text language sql security definer stable set search_path=public as
$$ select role from profiles where id=auth.uid() $$;
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as
$$ begin insert into profiles(id,email,full_name,role) values(new.id,new.email,new.raw_user_meta_data->>'full_name',case when exists(select 1 from admin_emails a where lower(a.email)=lower(new.email)) then 'admin' else 'customer' end); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Commande côté serveur : prix, variantes et stock vérifiés en base ; réservée aux comptes connectés
create function public.place_order(p_items jsonb,p_name text,p_phone text,p_address text) returns uuid
language plpgsql security definer set search_path=public as $$
declare oid uuid; it jsonb; pr products; vr product_variants; q int; vid uuid; u numeric; lb text; tot numeric:=0;
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  insert into orders(user_id,customer_name,phone,address) values(auth.uid(),p_name,p_phone,p_address) returning id into oid;
  for it in select * from jsonb_array_elements(p_items) loop
    q:=(it->>'quantity')::int; vid:=nullif(it->>'variant_id','')::uuid; lb:=null;
    select * into pr from products where id=(it->>'product_id')::uuid;
    if not found or q<1 then raise exception 'Produit invalide'; end if;
    if vid is not null then
      select * into vr from product_variants where id=vid and product_id=pr.id for update;
      if not found or vr.stock<q then raise exception 'Stock insuffisant : %', pr.name; end if;
      update product_variants set stock=stock-q where id=vid;
      u:=coalesce(vr.price,pr.sale_price,pr.price); lb:=concat_ws(' / ',vr.color,vr.type);
    else
      if exists(select 1 from product_variants where product_id=pr.id) then raise exception 'Choisissez une option pour %', pr.name; end if;
      select * into pr from products where id=pr.id for update;
      if pr.stock<q then raise exception 'Stock insuffisant : %', pr.name; end if;
      update products set stock=stock-q where id=pr.id; u:=coalesce(pr.sale_price,pr.price);
    end if;
    insert into order_items(order_id,product_id,variant_id,product_name,variant_label,unit_price,quantity) values(oid,pr.id,vid,pr.name,lb,u,q);
    tot:=tot+u*q;
  end loop;
  if tot=0 then raise exception 'Panier vide'; end if;
  update orders set total=tot where id=oid;
  delete from cart_items where user_id=auth.uid();
  return oid;
end $$;
revoke all on function public.place_order from public, anon;
grant execute on function public.place_order to authenticated;

alter table profiles enable row level security; alter table categories enable row level security; alter table products enable row level security;
alter table product_variants enable row level security; alter table orders enable row level security;
alter table order_items enable row level security; alter table cart_items enable row level security; alter table reviews enable row level security;

create policy cat_read on categories for select using (true);
create policy cat_admin on categories for all using (is_admin()) with check (is_admin());
create policy prod_read on products for select using (true);
create policy prod_admin on products for all using (is_admin()) with check (is_admin());
create policy var_read on product_variants for select using (true);
create policy var_admin on product_variants for all using (is_admin()) with check (is_admin());
create policy prof_read on profiles for select using (id=auth.uid() or is_admin());
create policy prof_upd on profiles for update using (id=auth.uid()) with check (id=auth.uid() and role=my_role());
create policy ord_read on orders for select using (user_id=auth.uid() or is_admin());
create policy ord_admin_upd on orders for update using (is_admin()) with check (is_admin());
create policy oi_read on order_items for select using (exists(select 1 from orders o where o.id=order_id and (o.user_id=auth.uid() or is_admin())));
create policy cart_own on cart_items for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy rev_read on reviews for select using (true);
create policy rev_ins on reviews for insert with check (user_id=auth.uid());
create policy rev_upd on reviews for update using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy rev_del on reviews for delete using (user_id=auth.uid() or is_admin());

insert into storage.buckets(id,name,public) values('product-images','product-images',true) on conflict do nothing;
create policy img_read on storage.objects for select using (bucket_id='product-images');
create policy img_admin on storage.objects for all using (bucket_id='product-images' and public.is_admin()) with check (bucket_id='product-images' and public.is_admin());

insert into categories(name,slug) values ('Power Banks','power-banks'),('Lampes LED','lampes-led'),('Supports téléphone','supports-telephone'),
 ('Chargeurs et câbles','chargeurs-cables'),('Accessoires gaming','accessoires-gaming'),('Audio et casques','audio-casques'),
 ('Électronique maison','electronique-maison'),('Accessoires auto','accessoires-auto'),('Électroménager cuisine','electromenager-cuisine'),('Outils et équipements','outils-equipements');

-- Produits d'exemple (à remplacer depuis l'admin avec vos vraies photos)
insert into products(category_id,name,description,price,sale_price,stock,is_featured)
select c.id,v.n,v.d,v.p,v.s,v.st,v.f from (values
 ('power-banks','Power bank 10 000 mAh','Batterie externe compacte avec deux ports USB.',59.900,49.900::numeric,0,true),
 ('lampes-led','Lampe de bureau LED','Lampe pliable à intensité réglable.',39.000,null,15,true),
 ('supports-telephone','Support téléphone voiture','Fixation aimantée pour tableau de bord.',19.500,null,40,false),
 ('chargeurs-cables','Câble USB-C 1 m','Câble tressé pour charge et transfert de données.',12.000,9.000,0,false),
 ('audio-casques','Casque audio Bluetooth','Casque sans fil pliable avec micro intégré.',89.000,null,0,true),
 ('outils-equipements','Jeu de tournevis de précision','Coffret de tournevis pour petits appareils.',24.500,null,30,false)
) as v(slug,n,d,p,s,st,f) join categories c on c.slug=v.slug;
insert into product_variants(product_id,color,type,stock)
select p.id,v.c,v.t,v.s from (values
 ('Power bank 10 000 mAh','Noir',null::text,12),('Power bank 10 000 mAh','Blanc',null,8),
 ('Casque audio Bluetooth','Noir',null,6),('Casque audio Bluetooth','Blanc',null,3),('Casque audio Bluetooth','Bleu',null,9),
 ('Câble USB-C 1 m','Noir','USB-C vers USB-C',40),('Câble USB-C 1 m','Noir','USB-C vers Lightning',20)
) as v(n,c,t,s) join products p on p.name=v.n;

-- Si votre e-mail admin était déjà inscrit avant ce script :
update profiles set role='admin' where lower(email) in (select lower(email) from admin_emails);
