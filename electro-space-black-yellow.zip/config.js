// Ouvrez ce fichier avec le Bloc-notes. Remplacez seulement les valeurs entre guillemets.
// Supabase : bouton "Connect" (en haut du tableau de bord) ou Settings > API Keys.
//   URL : "Project URL"            KEY : la clé "Publishable" (commence par sb_publishable_)
//   JAMAIS la clé "Secret" (sb_secret_...) ni "service_role".
window.CFG={
  URL:'https://VOTRE-PROJET.supabase.co',
  KEY:'VOTRE_CLE_PUBLISHABLE',
  WHATSAPP:'21600000000',   // numéro WhatsApp en format international, sans + ni espaces
  LOCK:true                 // true = il faut créer un compte pour entrer sur le site. false = visite libre, compte obligatoire pour acheter.
};
window.sb=supabase.createClient(CFG.URL,CFG.KEY);
window.CFG.ready=!CFG.URL.includes('VOTRE')&&!CFG.KEY.includes('VOTRE')&&!CFG.KEY.startsWith('sb_secret_');
