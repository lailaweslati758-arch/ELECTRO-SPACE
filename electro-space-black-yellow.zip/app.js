const sb=window.sb,$=s=>document.querySelector(s),app=$('#app');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n).toFixed(3).replace('.',',')+' DT';
const PH='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"><rect width="400" height="400" fill="#EEF4FF"/><g fill="none" stroke="#1447FF" stroke-width="10" stroke-linecap="round" opacity=".5"><path d="M150 130a90 90 0 1 0 100 0"/><path d="M200 90v100"/></g></svg>');
const COL={noir:'#2B2F36',blanc:'#FFFFFF',gris:'#8A94A6',bleu:'#1447FF',rouge:'#E11D2E',vert:'#16A34A',jaune:'#F5C400',orange:'#FF7A00',rose:'#FF6FA5',violet:'#7C3AED',argent:'#C0C7D1',or:'#D4AF37',marron:'#7B4A2B',beige:'#E8DCC8'};
const hex=c=>{c=(c||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');const k=Object.keys(COL).find(k=>c.includes(k));return k?COL[k]:'#CBD5E1'};
const sw=v=>`<i class="sw" style="background:${hex(v.color)}" title="${esc(v.color||'')}"></i>`;
const ST={en_attente:'En attente',confirmee:'Confirmée',expediee:'Expédiée',livree:'Livrée',annulee:'Annulée'};
const PAGES={cgv:['Conditions générales de vente','Les commandes passées sur Electro Space sont soumises aux présentes conditions. Les prix sont indiqués en dinars tunisiens (DT). Une commande est confirmée après validation par notre équipe. À compléter avec vos informations légales.'],
remboursement:['Politique de remboursement','Vous pouvez demander un retour ou un remboursement pour un produit défectueux ou non conforme. Contactez-nous avec votre numéro de commande. À compléter avec vos délais.'],
confidentialite:['Politique de confidentialité','Nous collectons uniquement les informations nécessaires au traitement de vos commandes (nom, e-mail, téléphone, adresse). Elles ne sont jamais revendues. À compléter.'],
livraison:['Livraison','Les commandes sont préparées après confirmation. Les délais et tarifs de livraison sont à préciser ici.'],
faq:['FAQ','Comment commander ? Créez un compte, ajoutez vos produits au panier puis validez la commande. Le paiement se fait à la livraison. À compléter avec vos questions fréquentes.'],
apropos:['À propos d\'Electro Space','Electro Space est une boutique en ligne d\'électronique : power banks, lampes LED, accessoires, audio, gaming, maison, auto, cuisine et outils.'],
contact:['Contact','Écrivez-nous à contact@electro-space.example ou via le bouton WhatsApp.']};
let user=null,prof=null,cats=[],prods=[],vars=[],revs=[],cart=[],sel=null,ret=null;
$('#wa').href='https://wa.me/'+CFG.WHATSAPP;
const toast=t=>{const e=$('#toast');e.textContent=t;e.className='show';setTimeout(()=>e.className='',2400)};
const lbl=v=>[v.color,v.type].filter(Boolean).join(' / ')||'Standard';
const vOf=id=>vars.filter(v=>v.product_id===id);
const stockOf=p=>{const v=vOf(p.id);return v.length?v.reduce((s,x)=>s+x.stock,0):p.stock};
const unit=(p,v)=>v&&v.price!=null?+v.price:(p.sale_price!=null?+p.sale_price:+p.price);
const cover=p=>p.image_url||vOf(p.id).find(v=>v.images?.length)?.images[0]||PH;
const priceHtml=(p,v)=>v&&v.price!=null?`<span class="now">${fmt(v.price)}</span>`:p.sale_price!=null?`<span class="now">${fmt(p.sale_price)}</span> <s>${fmt(p.price)}</s>`:`<span class="now">${fmt(p.price)}</span>`;
const batt=n=>{const k=n<=0?0:n<=3?1:n<=8?2:n<=15?3:n<=30?4:5;return `<p class="st"><span class="batt" aria-hidden="true">${[1,2,3,4,5].map(i=>`<i class="${i<=k?'f':''}"></i>`).join('')}</span>${n<=0?'Rupture de stock':n>10?'En stock':'Plus que '+n}</p>`};
const rOf=id=>revs.filter(r=>r.product_id===id);
const avg=l=>l.reduce((s,r)=>s+r.rating,0)/l.length;
const stars=n=>`<span class="stars" aria-label="${n.toFixed(1)} sur 5">${'★'.repeat(Math.round(n))}<span class="e">${'★'.repeat(5-Math.round(n))}</span></span>`;
const rateLine=id=>{const l=rOf(id);return l.length?`<p class="st">${stars(avg(l))} ${avg(l).toFixed(1).replace('.',',')} (${l.length})</p>`:''};
function card(p){const vs=vOf(p.id),n=stockOf(p),off=p.sale_price!=null&&!vs.some(v=>v.price!=null);
 return `<article class="pc"><a class="im" href="#/produit/${p.id}"><img src="${esc(cover(p))}" alt="${esc(p.name)}" loading="lazy">${off?`<span class="off">-${Math.round(100-p.sale_price/p.price*100)}%</span>`:''}</a><h3><a href="#/produit/${p.id}">${esc(p.name)}</a></h3>${vs.length?`<div class="sws">${vs.slice(0,6).map(sw).join('')}${vs.length>6?`<small>+${vs.length-6}</small>`:''}</div>`:''}<p class="pr">${priceHtml(p)}</p>${rateLine(p.id)}${batt(n)}<div class="act">${vs.length?`<a class="btn sm" href="#/produit/${p.id}">Choisir une option</a>`:`<button class="btn sm" data-add="${p.id}" ${n>0?'':'disabled'}>Ajouter au panier</button>`}</div></article>`}
async function loadCart(){if(!user){cart=[];$('#cnt').textContent=0;return}const{data}=await sb.from('cart_items').select('*').eq('user_id',user.id).order('created_at');cart=data||[];$('#cnt').textContent=cart.reduce((s,c)=>s+c.quantity,0)}
function needLogin(){if(user)return false;ret=location.hash;toast('Créez un compte ou connectez-vous pour acheter');location.hash='#/connexion';return true}
async function add(pid,vid,q=1){if(needLogin())return;const p=prods.find(x=>x.id===pid),v=vid?vars.find(x=>x.id===vid):null;
 if(vOf(pid).length&&!v)return toast('Choisissez une option');const max=v?v.stock:p.stock,row=cart.find(c=>c.product_id===pid&&(c.variant_id||null)===(vid||null)),n=(row?row.quantity:0)+q;
 if(n>max)return toast('Stock insuffisant');
 const{error}=row?await sb.from('cart_items').update({quantity:n}).eq('id',row.id):await sb.from('cart_items').insert({user_id:user.id,product_id:pid,variant_id:vid||null,quantity:q});
 if(error)return toast(error.message);await loadCart();toast('Ajouté au panier')}
async function setUser(){const{data:{session}}=await sb.auth.getSession();user=session?.user||null;prof=null;
 if(user)prof=(await sb.from('profiles').select('*').eq('id',user.id).single()).data;
 $('#acc').textContent=user?'Mon compte':'Connexion';$('#acc').href=user?'#/compte':'#/connexion';await loadCart()}
async function load(){const[a,b,c,d]=await Promise.all([sb.from('categories').select('*').order('name'),sb.from('products').select('*').order('created_at',{ascending:false}),sb.from('product_variants').select('*').order('created_at'),sb.from('reviews').select('*').order('created_at',{ascending:false})]);
 cats=a.data||[];prods=b.data||[];vars=c.data||[];revs=d.data||[];$('#fcats').innerHTML=cats.map(c=>`<a href="#/catalogue?c=${esc(c.slug)}">${esc(c.name)}</a>`).join('')}
const sec=(t,l,more)=>l.length?`<section><div class="sh"><h2>${t}</h2><a href="${more}">Tout voir</a></div><div class="grid">${l.slice(0,4).map(card).join('')}</div></section>`:'';
function vHome(){const f=prods[0];
 return `<section class="hero" style="margin-top:16px"><svg class="pw" viewBox="0 0 400 400" aria-hidden="true"><path pathLength="1" d="M135 95A140 140 0 1 0 265 95"/><path pathLength="1" d="M200 30V190"/></svg>
<div><h1>Branchez, chargez, écoutez.</h1><p>Power banks, câbles, casques, lampes et accessoires du quotidien. Choisissez votre couleur, commandez en quelques clics.</p><a class="btn" href="#/catalogue">Voir le catalogue</a></div>
${f?`<a class="fiche" href="#/produit/${f.id}"><div class="im"><img src="${esc(cover(f))}" alt="${esc(f.name)}"></div><b>${esc(f.name)}</b><span>Dernier ajout · ${fmt(unit(f))}</span></a>`:''}</section>
<section class="visual-picks"><div class="sh"><div><p class="st">LA SÉLECTION ELECTRO SPACE</p><h2>Les essentiels tech</h2></div><a href="#/catalogue">Explorer le catalogue</a></div><div class="grid"><article class="pc"><div class="im"><img src="assets/products/power-bank.webp" alt="Power bank noir 20000 mAh" loading="lazy"></div><h3>Power banks</h3><p class="st">L'énergie partout avec vous</p></article><article class="pc"><div class="im"><img src="assets/products/casque-audio.webp" alt="Casque audio sans fil noir" loading="lazy"></div><h3>Audio & casques</h3><p class="st">Un son qui vous accompagne</p></article><article class="pc"><div class="im"><img src="assets/products/lampe-led.webp" alt="Lampe LED de bureau" loading="lazy"></div><h3>Lampes LED</h3><p class="st">Éclairez votre espace</p></article><article class="pc"><div class="im"><img src="assets/products/enceinte-bluetooth.webp" alt="Enceinte Bluetooth portable" loading="lazy"></div><h3>Enceintes Bluetooth</h3><p class="st">Votre musique, partout</p></article></div></section>
<section><div class="sh"><h2>Catégories</h2></div><div class="bento">${cats.map(c=>`<a href="#/catalogue?c=${esc(c.slug)}">${esc(c.name)}<small>${prods.filter(p=>p.category_id===c.id).length} produits</small></a>`).join('')}</div></section>
${sec('À la une',prods.filter(p=>p.is_featured),'#/catalogue')}${sec('Offres du moment',prods.filter(p=>p.sale_price!=null),'#/catalogue?o=1')}${sec('Nouveautés',prods,'#/catalogue')}
<section class="ben"><div><h3>Paiement à la livraison</h3><p>Vous réglez à la réception, sans saisir de carte bancaire.</p></div><div><h3>Livraison</h3><p>Votre commande est préparée dès sa confirmation.</p></div><div><h3>Aide par WhatsApp</h3><p>Une question avant d'acheter ? Écrivez-nous.</p></div></section>`}
const vCategories=()=>`<h1>Catégories</h1><div class="bento">${cats.map(c=>`<a href="#/catalogue?c=${esc(c.slug)}">${esc(c.name)}<small>${prods.filter(p=>p.category_id===c.id).length} produits</small></a>`).join('')}</div>`;
function vCat(q){const c=q.get('c'),s=(q.get('q')||'').toLowerCase(),o=q.get('o');
 const l=prods.filter(p=>(!c||cats.find(x=>x.id===p.category_id)?.slug===c)&&(!s||(p.name+' '+(p.description||'')).toLowerCase().includes(s))&&(!o||p.sale_price!=null));
 return `<h1>${o?'Offres du moment':'Catalogue'}</h1><div class="chips"><a class="${!c?'on':''}" href="#/catalogue">Tout</a>${cats.map(x=>`<a class="${c===x.slug?'on':''}" href="#/catalogue?c=${esc(x.slug)}">${esc(x.name)}</a>`).join('')}</div>${s?`<p style="margin-bottom:20px">${l.length} résultat(s) pour « ${esc(s)} »</p>`:''}<div class="grid">${l.map(card).join('')||'<p>Aucun produit ne correspond. Essayez une autre catégorie ou un autre mot.</p>'}</div>`}
function reviewsHtml(id){const l=rOf(id),mine=user&&l.find(r=>r.user_id===user.id);
 return `<section><h2>Avis clients</h2>${l.length?`<p>${stars(avg(l))} <b>${avg(l).toFixed(1).replace('.',',')} sur 5</b> (${l.length} avis)</p>`:'<p>Aucun avis pour le moment. Soyez le premier à donner votre avis.</p>'}
 ${user?`<form id="rv" class="form" data-pid="${id}"><label>Votre note</label><div class="rate">${[5,4,3,2,1].map(i=>`<input type="radio" id="r${i}" name="rating" value="${i}" ${mine?.rating===i?'checked':''} required><label for="r${i}" title="${i} étoile(s)">★</label>`).join('')}</div><label>Votre commentaire<textarea name="comment" rows="3">${esc(mine?.comment)}</textarea></label><button class="btn">${mine?'Modifier mon avis':'Publier mon avis'}</button></form>`:'<p class="note">Connectez-vous pour donner votre avis.</p>'}
 <div class="revs">${l.map(r=>`<div class="rev">${stars(r.rating)} <b>${esc(r.author_name||'Client')}</b> <span class="st">${new Date(r.created_at).toLocaleDateString('fr-FR')}</span>${r.comment?`<p>${esc(r.comment)}</p>`:''}</div>`).join('')}</div></section>`}
function vProd(id){const p=prods.find(x=>x.id===id);if(!p)return'<h1>Produit introuvable</h1><a class="btn" href="#/catalogue">Retour au catalogue</a>';
 const vs=vOf(id),c=cats.find(x=>x.id===p.category_id);if(vs.length&&!vs.some(v=>v.id===sel))sel=(vs.find(v=>v.stock>0)||vs[0]).id;
 const v=vs.length?vs.find(x=>x.id===sel):null,imgs=v?.images?.length?v.images:[cover(p)],n=v?v.stock:p.stock;
 return `<div class="detail"><div><div class="im"><img id="mainimg" src="${esc(imgs[0])}" alt="${esc(p.name)}"></div>${imgs.length>1?`<div class="th">${imgs.map(u=>`<img src="${esc(u)}" data-img="${esc(u)}" alt="Autre vue" tabindex="0">`).join('')}</div>`:''}</div>
<div>${c?`<a href="#/catalogue?c=${esc(c.slug)}">${esc(c.name)}</a>`:''}<h1>${esc(p.name)}</h1><p>${priceHtml(p,v)}</p>${batt(n)}<p style="margin:16px 0">${esc(p.description)}</p>
${vs.length?`<b>Option : ${esc(lbl(v))}</b><div class="opts">${vs.map(x=>`<button class="opt ${x.id===sel?'on':''}" data-var="${x.id}" ${x.stock>0?'':'disabled'}>${sw(x)}${esc(lbl(x))}</button>`).join('')}</div>`:''}
${n>0?`<div class="buy"><div class="qty"><button data-pq="-1" aria-label="Diminuer">−</button><b id="pq">1</b><button data-pq="1" data-max="${n}" aria-label="Augmenter">+</button></div><button class="btn" data-addq="${p.id}">Ajouter au panier</button></div>`:'<p class="ko">Cette option est en rupture de stock.</p>'}</div></div>${reviewsHtml(p.id)}`}
const rowsOf=()=>cart.map(c=>({c,p:prods.find(x=>x.id===c.product_id),v:vars.find(x=>x.id===c.variant_id)})).filter(r=>r.p);
const totalOf=rows=>rows.reduce((s,r)=>s+unit(r.p,r.v)*r.c.quantity,0);
function vCart(){if(!user)return vAuth('Connectez-vous pour retrouver votre panier et commander.');const rows=rowsOf();
 if(!rows.length)return'<h1>Mon panier</h1><p style="margin-bottom:18px">Votre panier est vide.</p><a class="btn" href="#/catalogue">Voir le catalogue</a>';
 return `<h1>Mon panier</h1><div class="cartwrap"><div>${rows.map(({c,p,v})=>`<div class="row"><div class="im"><img src="${esc(v?.images?.[0]||cover(p))}" alt=""></div><div class="grow"><a href="#/produit/${p.id}"><b>${esc(p.name)}</b></a><br><span class="st">${v?esc(lbl(v))+' · ':''}${fmt(unit(p,v))}</span></div><div class="qty"><button data-dec="${c.id}" aria-label="Diminuer">−</button><b>${c.quantity}</b><button data-inc="${c.id}" aria-label="Augmenter">+</button></div><b>${fmt(unit(p,v)*c.quantity)}</b><button class="x" data-del="${c.id}">Retirer</button></div>`).join('')}</div>
<aside class="sum"><h2>Total</h2><p class="big">${fmt(totalOf(rows))}</p><a class="btn" href="#/commande">Passer la commande</a></aside></div>`}
const vAuth=m=>`${m?`<p class="note">${m}</p>`:''}<h1>Votre compte</h1><div class="two"><form id="lf" class="pn"><h2>Se connecter</h2><label>E-mail<input name="email" type="email" required></label><label>Mot de passe<input name="password" type="password" required></label><button class="btn">Se connecter</button><p class="ko" id="e1"></p></form>
<form id="rf" class="pn"><h2>Créer un compte</h2><label>Nom complet<input name="name" required></label><label>E-mail<input name="email" type="email" required></label><label>Mot de passe (6 caractères minimum)<input name="password" type="password" minlength="6" required></label><button class="btn">Créer mon compte</button><p class="ko" id="e2"></p></form></div>`;
function vCheckout(){if(!user)return vAuth('Connectez-vous pour finaliser votre commande.');const rows=rowsOf();if(!rows.length)return vCart();
 return `<h1>Finaliser la commande</h1><form id="co" class="form"><label>Nom complet<input name="name" value="${esc(prof?.full_name)}" required></label><label>Téléphone<input name="phone" value="${esc(prof?.phone)}" required></label><label>Adresse de livraison<textarea name="address" rows="3" required></textarea></label><p>Paiement à la livraison</p><p class="big">${fmt(totalOf(rows))}</p><button class="btn">Confirmer la commande</button><p class="ko" id="e3"></p></form>`}
const ordersHtml=os=>os.length?os.map(o=>`<div class="order"><b>Commande du ${new Date(o.created_at).toLocaleDateString('fr-FR')}</b> : ${ST[o.status]}, ${fmt(o.total)}<ul>${o.order_items.map(i=>`<li>${esc(i.product_name)}${i.variant_label?' ('+esc(i.variant_label)+')':''} × ${i.quantity}</li>`).join('')}</ul></div>`).join(''):'<p>Aucune commande pour le moment.</p>';
async function vAccount(){if(!user)return vAuth();const{data}=await sb.from('orders').select('*,order_items(*)').order('created_at',{ascending:false});
 return `<h1>Mon compte</h1><p style="margin-bottom:14px">${esc(user.email)}${prof?.role==='admin'?' · <a href="admin.html">Administration</a>':''}</p><form id="pf" class="form"><label>Nom complet<input name="name" value="${esc(prof?.full_name)}"></label><label>Téléphone<input name="phone" value="${esc(prof?.phone)}"></label><button class="btn">Enregistrer</button> <button type="button" class="btn ghost" data-out="1">Se déconnecter</button></form><h2 style="margin:36px 0 16px">Mes commandes</h2>${ordersHtml(data||[])}`}
async function vConfirm(id){const{data}=await sb.from('orders').select('*,order_items(*)').eq('id',id).single();return data?`<h1>Commande enregistrée</h1><p style="margin-bottom:18px">Numéro ${id.slice(0,8).toUpperCase()}. Nous vous appelons pour la confirmer.</p>${ordersHtml([data])}<a class="btn" href="#/catalogue">Continuer mes achats</a>`:'<h1>Commande introuvable</h1>'}
async function route(){if(!CFG.ready){app.innerHTML='<div class="note"><b>Configuration requise.</b> Renseignez l\'URL et la clé publique (publishable) Supabase, jamais la clé secrète, dans config.js, puis exécutez schema.sql.</div>';return}
 const[path,qs]=(location.hash.slice(1)||'/').split('?'),[r,a]=path.split('/').filter(Boolean),q=new URLSearchParams(qs||'');await load();let h;
 if(CFG.LOCK&&!user&&r!=='connexion'&&r!=='page')h=vAuth('Connectez-vous ou créez un compte pour accéder à la boutique.');
 else if(!r)h=vHome();else if(r==='catalogue')h=vCat(q);else if(r==='categories')h=vCategories();else if(r==='produit')h=vProd(a);else if(r==='panier')h=vCart();else if(r==='commande')h=vCheckout();
 else if(r==='connexion')h=user?await vAccount():vAuth();else if(r==='compte')h=await vAccount();else if(r==='confirmation')h=await vConfirm(a);
 else if(r==='page'&&PAGES[a])h=`<h1>${PAGES[a][0]}</h1><p style="max-width:62ch">${PAGES[a][1]}</p>`;else h='<h1>Page introuvable</h1>';
 app.innerHTML=h;scrollTo(0,0)}
document.addEventListener('click',async e=>{const im=e.target.closest('[data-img]');if(im){$('#mainimg').src=im.dataset.img;return}
 const t=e.target.closest('button');if(!t)return;const D=t.dataset;
 if(D.add)add(D.add,null);
 else if(D.addq)add(D.addq,vOf(D.addq).length?sel:null,+$('#pq').textContent);
 else if(D.var){sel=D.var;app.innerHTML=vProd(location.hash.split('/')[2])}
 else if(D.pq){const m=+(document.querySelector('[data-max]')?.dataset.max||99);$('#pq').textContent=Math.min(m,Math.max(1,+$('#pq').textContent+ +D.pq))}
 else if(D.inc||D.dec||D.del){const id=D.inc||D.dec||D.del,c=cart.find(x=>x.id===id),p=prods.find(x=>x.id===c.product_id),v=vars.find(x=>x.id===c.variant_id);let err;
  if(D.del||(D.dec&&c.quantity<=1))err=(await sb.from('cart_items').delete().eq('id',id)).error;
  else if(D.inc){if(c.quantity+1>(v?v.stock:p.stock))return toast('Stock insuffisant');err=(await sb.from('cart_items').update({quantity:c.quantity+1}).eq('id',id)).error}
  else err=(await sb.from('cart_items').update({quantity:c.quantity-1}).eq('id',id)).error;
  if(err)return toast(err.message);await loadCart();route()}
 else if(D.out){await sb.auth.signOut();user=prof=null;await loadCart();$('#acc').textContent='Connexion';$('#acc').href='#/connexion';location.hash='#/';route()}});
document.addEventListener('submit',async e=>{e.preventDefault();const f=e.target,d=Object.fromEntries(new FormData(f)),msg=(id,t)=>$('#'+id).textContent=t;
 if(f.id==='sf'){location.hash='#/catalogue?q='+encodeURIComponent(d.q)}
 else if(f.id==='lf'){const{error}=await sb.auth.signInWithPassword({email:d.email,password:d.password});if(error)return msg('e1','E-mail ou mot de passe incorrect.');await setUser();location.hash=ret||'#/compte';ret=null;route()}
 else if(f.id==='rf'){const{data,error}=await sb.auth.signUp({email:d.email,password:d.password,options:{data:{full_name:d.name}}});if(error)return msg('e2',error.message);
  if(data.session){await setUser();location.hash=ret||'#/compte';ret=null;route()}else msg('e2','Compte créé. Confirmez votre e-mail, puis connectez-vous.')}
 else if(f.id==='rv'){const{error}=await sb.from('reviews').upsert({product_id:f.dataset.pid,user_id:user.id,rating:+d.rating,comment:(d.comment||'').trim()||null,author_name:prof?.full_name||user.email.split('@')[0]},{onConflict:'product_id,user_id'});if(error)return toast(error.message);toast('Merci pour votre avis');route()}
 else if(f.id==='pf'){const{error}=await sb.from('profiles').update({full_name:d.name,phone:d.phone}).eq('id',user.id);if(error)return toast(error.message);prof={...prof,full_name:d.name,phone:d.phone};toast('Profil enregistré')}
 else if(f.id==='co'){const{data,error}=await sb.rpc('place_order',{p_items:cart.map(c=>({product_id:c.product_id,variant_id:c.variant_id,quantity:c.quantity})),p_name:d.name,p_phone:d.phone,p_address:d.address});
  if(error)return msg('e3',error.message);await loadCart();location.hash='#/confirmation/'+data}});
addEventListener('hashchange',route);
(async()=>{if(CFG.ready)await setUser();route()})();
